package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BrowserViewModel
import kotlinx.coroutines.launch

@Composable
fun DevToolsPanel(viewModel: BrowserViewModel) {
    var devTab by remember { mutableStateOf("CONSOLE") } // "CONSOLE", "NETWORK", "DOM", "PERF"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
    ) {
        // DevTools tab header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            val tabs = listOf("CONSOLE", "NETWORK", "DOM", "PERF")
            for (tab in tabs) {
                val active = devTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (active) Color(0xFF1E2235) else Color.Transparent)
                        .clickable { devTab = tab }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        color = if (active) Color(0xFF00F5FF) else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (devTab) {
                "CONSOLE" -> ConsoleLogsTab(viewModel)
                "NETWORK" -> NetworkLogsTab(viewModel)
                "DOM" -> DomInspectorTab(viewModel)
                "PERF" -> PerformanceTab(viewModel)
            }
        }
    }
}

@Composable
fun ConsoleLogsTab(viewModel: BrowserViewModel) {
    val logs by viewModel.consoleLogs.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("JS CONSOLE STREAM:", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            IconButton(onClick = { viewModel.clearDevToolsLogs() }) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear", tint = Color.Gray)
            }
        }

        if (logs.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Console logs stream is empty.", color = Color.DarkGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(logs) { log ->
                    val color = when (log.level) {
                        "ERROR" -> Color.Red
                        "WARN" -> Color(0xFFFFB300)
                        else -> Color(0xFF00F5FF)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF08090D), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "[${log.level}]",
                            color = color,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = log.message,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NetworkLogsTab(viewModel: BrowserViewModel) {
    val requests by viewModel.networkRequests.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("API & SECURE WEB SOCKET LOGS:", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            IconButton(onClick = { viewModel.clearDevToolsLogs() }) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear", tint = Color.Gray)
            }
        }

        if (requests.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No network traffic captured yet.", color = Color.DarkGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(requests) { req ->
                    val color = if (req.statusCode == 403) Color.Red else Color(0xFF39FF14)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF08090D), RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = req.method,
                            color = Color(0xFFFF007F),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = req.url,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1
                            )
                            Text(
                                text = "Mime: ${req.mimeType}",
                                color = Color.Gray,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = req.statusCode.toString(),
                            color = color,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DomInspectorTab(viewModel: BrowserViewModel) {
    val domText by viewModel.domSource.collectAsState()
    val clipboard = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()
    var displayMessage by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    clipboard.setText(AnnotatedString(domText))
                    displayMessage = "HTML DOM copied to clipboard!"
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2235)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF00F5FF), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("COPY DOM SOURCE", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                }
            }

            Button(
                onClick = {
                    viewModel.askAiAssistant(
                        prompt = "Perform complete security and DOM architectural inspection. Identify injection risks, third-party cookies trackers, and outdated script headers.",
                        contextText = domText.take(2000)
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF007F)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1.5f),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AI CODE INSPECTION", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                }
            }
        }

        if (displayMessage.isNotEmpty()) {
            Text(displayMessage, color = Color(0xFF39FF14), fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp), fontFamily = FontFamily.Monospace)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF05060A)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f).fillMaxWidth().border(1.dp, Color(0xFF1E2235), RoundedCornerShape(8.dp))
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                item {
                    Text(
                        text = if (domText.isNotEmpty()) domText else "No source code loaded. Navigate to a site first.",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
fun PerformanceTab(viewModel: BrowserViewModel) {
    val fpsValue by viewModel.fpsValue.collectAsState()
    val cpuValue by viewModel.cpuValue.collectAsState()
    val memoryUsage by viewModel.memoryUsage.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Performance Stats
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF1E2235), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("REAL-TIME ENGINE TELEMETRY", color = Color(0xFF00F5FF), fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("CPU LOAD", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("$cpuValue %", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("FPS", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("$fpsValue Hz", color = Color(0xFF39FF14), fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("USED MEMORY", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(memoryUsage, color = Color(0xFFFF007F), fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Telemetry stats details
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("GPU ACCELERATION METRICS:", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Render System: hardware-accelerated GLES 3.1", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Graphics Adapter: Vulkan Driver Pipeline API", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Viewport Composition: Layer Compositor Vsync Sync", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Caching State: Memory cached, Cache-control validated", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
