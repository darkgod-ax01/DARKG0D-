package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent?
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>?
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object RetrofitClient {
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

object AiHelper {
    private fun getApiKey(): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isEmpty() || key == "MY_GEMINI_API_KEY") "" else key
        } catch (e: Exception) {
            ""
        }
    }

    suspend fun generateResponse(
        prompt: String,
        systemPrompt: String? = null,
        history: List<Pair<String, Boolean>> = emptyList() // Pair of <Message, isUser>
    ): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) {
            return@withContext "API KEY MISSING. Please configure your GEMINI_API_KEY in the Secrets panel in AI Studio to unlock advanced AI capabilities."
        }

        // Build contents from history + current prompt
        val contents = mutableListOf<GeminiContent>()
        for (turn in history) {
            contents.add(GeminiContent(parts = listOf(GeminiPart(text = turn.first))))
        }
        contents.add(GeminiContent(parts = listOf(GeminiPart(text = prompt))))

        val systemInstruction = systemPrompt?.let {
            GeminiContent(parts = listOf(GeminiPart(text = it)))
        }

        val request = GeminiRequest(
            contents = contents,
            systemInstruction = systemInstruction
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "Empty response from AI engine."
        } catch (e: Exception) {
            "Engine Error: ${e.localizedMessage ?: "Could not connect to Gemini service."}"
        }
    }

    suspend fun summarizePage(url: String, content: String): String {
        val system = "You are DARK BROWSER AI, a privacy-focused expert. Summarize the content of the page at the given URL concisely. Highlight key takeaways, technical parameters, and structure it cleanly using simple bullet points."
        val prompt = "URL: $url\n\nContent:\n$content"
        return generateResponse(prompt, system)
    }

    suspend fun explainCode(url: String, code: String): String {
        val system = "You are DARK BROWSER Developer Companion. Analyze and explain the provided source code, elements, or script snippet. Detail the architectural flow, functions, and provide debugging tips."
        val prompt = "URL: $url\n\nCode/Source Snippet:\n$code"
        return generateResponse(prompt, system)
    }

    suspend fun translateContent(content: String, targetLanguage: String): String {
        val system = "You are an expert translator. Translate the provided text into $targetLanguage. Retain formatting, markdown, lists, and keep specialized developer terms untranslated."
        return generateResponse(content, system)
    }
}
