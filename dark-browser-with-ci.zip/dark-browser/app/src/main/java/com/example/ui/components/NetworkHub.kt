package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DnsServer
import com.example.data.VpnDnsProxyManager
import com.example.data.VpnServer
import kotlinx.coroutines.launch

@Composable
fun NetworkHub() {
    var selectedTab by remember { mutableStateOf("VPN") } // "VPN", "DNS", "PROXY"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
    ) {
        // Tab Headers
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            val tabs = listOf("VPN", "DNS", "PROXY")
            for (tab in tabs) {
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF1E2235) else Color.Transparent)
                        .clickable { selectedTab = tab }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        color = if (isSelected) Color(0xFF00F5FF) else Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Inner Content
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                "VPN" -> VpnTabContent()
                "DNS" -> DnsTabContent()
                "PROXY" -> ProxyTabContent()
            }
        }
    }
}

@Composable
fun VpnTabContent() {
    val isConnected by VpnDnsProxyManager.isVpnConnected.collectAsState()
    val activeServer by VpnDnsProxyManager.selectedVpnServer.collectAsState()
    val sentBytes by VpnDnsProxyManager.vpnSentBytes.collectAsState()
    val recvBytes by VpnDnsProxyManager.vpnReceivedBytes.collectAsState()
    val connectionSpeed by VpnDnsProxyManager.vpnSpeed.collectAsState()
    val sessionTime by VpnDnsProxyManager.vpnConnectedTime.collectAsState()

    var killSwitch by remember { mutableStateOf(true) }
    var splitTunneling by remember { mutableStateOf(false) }

    val formattedTime = String.format(
        "%02d:%02d:%02d",
        sessionTime / 3600,
        (sessionTime % 3600) / 60,
        sessionTime % 60
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // VPN Power Button
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(50.dp))
                            .background(
                                Brush.radialGradient(
                                    colors = if (isConnected) {
                                        listOf(Color(0xFF39FF14).copy(alpha = 0.2f), Color.Transparent)
                                    } else {
                                        listOf(Color(0xFFFF007F).copy(alpha = 0.15f), Color.Transparent)
                                    }
                                )
                            )
                            .clickable { VpnDnsProxyManager.toggleVpn() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Power",
                            tint = if (isConnected) Color(0xFF39FF14) else Color(0xFFFF007F),
                            modifier = Modifier.size(52.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = if (isConnected) "SECURE TUNNEL ACTIVE" else "DISCONNECTED",
                        color = if (isConnected) Color(0xFF39FF14) else Color(0xFFFF007F),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "IP: ${activeServer.ipAddress} (${activeServer.name})",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    if (isConnected) {
                        Spacer(modifier = Modifier.height(24.dp))
                        // Stats Grid
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SESSION TIME", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text(formattedTime, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SPEED", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text(connectionSpeed, color = Color(0xFF00F5FF), fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SENT DATA", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text("${sentBytes / 1024} KB", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
                            }
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("RECEIVED DATA", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text("${recvBytes / (1024 * 1024)} MB", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Toggles list
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, tint = Color(0xFF00F5FF), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("VPN Kill Switch", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Block connections when VPN drops", color = Color.Gray, fontSize = 10.sp)
                        }
                        Switch(
                            checked = killSwitch,
                            onCheckedChange = { killSwitch = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F5FF))
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AltRoute, contentDescription = null, tint = Color(0xFF00F5FF), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Split Tunneling", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Allow some traffic to bypass VPN", color = Color.Gray, fontSize = 10.sp)
                        }
                        Switch(
                            checked = splitTunneling,
                            onCheckedChange = { splitTunneling = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F5FF))
                        )
                    }
                }
            }
        }

        // Region Selection Header
        item {
            Text(
                text = "SELECT CYBER REGION:",
                color = Color(0xFF00F5FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Region list
        items(VpnDnsProxyManager.vpnServers) { server ->
            val isActive = activeServer.id == server.id
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isActive) Color(0xFF1E2235) else Color(0xFF0F111A))
                    .clickable {
                        VpnDnsProxyManager.selectedVpnServer.value = server
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(server.flag, fontSize = 24.sp)
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = server.name,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "IP: ${server.ipAddress}",
                        color = Color.Gray,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.NetworkWifi,
                        contentDescription = null,
                        tint = if (server.ping < 50) Color(0xFF39FF14) else if (server.ping < 120) Color(0xFFFFB300) else Color.Red,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${server.ping} ms",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (server.isPremium) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFFFB300), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text("PREMIUM", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun DnsTabContent() {
    val coroutineScope = rememberCoroutineScope()
    val activeDns by VpnDnsProxyManager.selectedDns.collectAsState()
    val dnsProtocol by VpnDnsProxyManager.dnsProtocol.collectAsState()
    var isTesting by remember { mutableStateOf(false) }
    var benchmarkList by remember { mutableStateOf<List<DnsServer>>(emptyList()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active DNS configuration Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.SettingsEthernet, contentDescription = null, tint = Color(0xFF00F5FF))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "ACTIVE SECURE DNS ENGINE",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(activeDns.name, color = Color(0xFF00F5FF), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(activeDns.securityAnalysis, color = Color.Gray, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(16.dp))

                    // Protocol Selection Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val protocols = listOf("DoH", "DoT", "DoQ")
                        for (proto in protocols) {
                            val active = dnsProtocol == proto
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) Color(0xFF1E2235) else Color(0xFF05060A))
                                    .border(1.dp, if (active) Color(0xFF00F5FF) else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { VpnDnsProxyManager.dnsProtocol.value = proto }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(proto, color = if (active) Color.White else Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Speed Test & Benchmark Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "DNS SECURITY & SPEED BENCHMARK",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Run a latency test across all pre-configured privacy servers to identify the fastest secure route.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isTesting = true
                                val list = VpnDnsProxyManager.runDnsBenchmark()
                                benchmarkList = list
                                isTesting = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F5FF)),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isTesting
                    ) {
                        if (isTesting) {
                            CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                        } else {
                            Text("RUN DNS BENCHMARK TEST", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    if (benchmarkList.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (server in benchmarkList) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF08090D), RoundedCornerShape(6.dp))
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(server.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(server.address, color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    Text(
                                        "${server.pingResult ?: 0} ms",
                                        color = if ((server.pingResult ?: 0) < 25) Color(0xFF39FF14) else Color(0xFFFFB300),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Available DNS Servers
        item {
            Text(
                "SELECT SECURE PROTOCOL PROVIDER:",
                color = Color(0xFF00F5FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(VpnDnsProxyManager.dnsServers) { dns ->
            val isCurrent = activeDns.name == dns.name
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isCurrent) Color(0xFF1E2235) else Color(0xFF0F111A))
                    .clickable { VpnDnsProxyManager.selectedDns.value = dns }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isCurrent) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isCurrent) Color(0xFF00F5FF) else Color.Gray
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(dns.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Server Address: ${dns.address}", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                if (dns.isRecommended) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF39FF14).copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("FASTEST", color = Color(0xFF39FF14), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun ProxyTabContent() {
    val coroutineScope = rememberCoroutineScope()
    val proxyProfiles by VpnDnsProxyManager.proxyProfiles.collectAsState()
    val activeIndex by VpnDnsProxyManager.activeProxyIndex.collectAsState()

    var hostInput by remember { mutableStateOf("") }
    var portInput by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("SOCKS5") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Toggle Proxy Status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.VpnLock, contentDescription = null, tint = Color(0xFF00F5FF))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("PROXY PROFILE TUNNELLING", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (activeIndex >= 0) "ACTIVE: ${proxyProfiles[activeIndex].name}" else "Proxy routing is currently bypassed",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                    if (activeIndex >= 0) {
                        Button(
                            onClick = { VpnDnsProxyManager.activeProxyIndex.value = -1 },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text("DISABLE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Add Proxy Form Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "REGISTER CUSTOM PROXY SERVER",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = hostInput,
                            onValueChange = { hostInput = it },
                            label = { Text("Proxy Host/IP") },
                            modifier = Modifier.weight(2f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF00F5FF),
                                unfocusedBorderColor = Color(0xFF1E2235)
                            )
                        )

                        OutlinedTextField(
                            value = portInput,
                            onValueChange = { portInput = it },
                            label = { Text("Port") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF00F5FF),
                                unfocusedBorderColor = Color(0xFF1E2235)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val types = listOf("HTTP", "HTTPS", "SOCKS4", "SOCKS5")
                        for (type in types) {
                            val active = selectedType == type
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) Color(0xFF1E2235) else Color(0xFF08090D))
                                    .border(1.dp, if (active) Color(0xFF00F5FF) else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { selectedType = type }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(type, color = if (active) Color.White else Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val port = portInput.toIntOrNull() ?: 8080
                            if (hostInput.isNotEmpty()) {
                                val current = VpnDnsProxyManager.proxyProfiles.value.toMutableList()
                                current.add(com.example.data.ProxyProfile("Custom ${current.size + 1}", hostInput, port, selectedType))
                                VpnDnsProxyManager.proxyProfiles.value = current.toList()
                                hostInput = ""
                                portInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF007F)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SAVE PROXY HANDSHAKE PROFILE", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Active profiles
        item {
            Text(
                "SAVED PROXY ROUTES:",
                color = Color(0xFF00F5FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(proxyProfiles.indices.toList()) { index ->
            val profile = proxyProfiles[index]
            val isCurrent = index == activeIndex
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isCurrent) Color(0xFF1E2235) else Color(0xFF0F111A))
                    .clickable {
                        VpnDnsProxyManager.activeProxyIndex.value = index
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(profile.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFFF007F).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(profile.type, color = Color(0xFFFF007F), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("${profile.host}:${profile.port}", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (profile.latency != null) "${profile.latency} ms" else "Unchecked",
                        color = if (profile.health == "Healthy") Color(0xFF39FF14) else Color.LightGray,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(12.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                VpnDnsProxyManager.runProxyTest(index)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF131522)),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("TEST", fontSize = 9.sp, color = Color(0xFF00F5FF), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
