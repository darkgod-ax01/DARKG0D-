package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyberpunk AMOLED Theme Colors
val CyberBlack = Color(0xFF000000)
val CyberGrey = Color(0xFF0D0E15)
val CyberCard = Color(0xFF131522)
val CyberCyan = Color(0xFF00F5FF) // Vibrant Cyan
val CyberPink = Color(0xFFFF007F) // Hot Cyber Pink
val CyberBlue = Color(0xFF0A192F) // Deep space blue
val CyberGreen = Color(0xFF39FF14) // Neon Green
val CyberAmber = Color(0xFFFFB300) // Neon Amber / Gold

// Standard dark theme overrides
val DarkBg = Color(0xFF0B0C10)
val DarkSurface = Color(0xFF1F2833)
val DarkPrimary = Color(0xFF66FCF1)
val DarkSecondary = Color(0xFF45A29E)

// Text Colors
val TextPrimaryDark = Color(0xFFF0F4F8)
val TextSecondaryDark = Color(0xFF98A6AD)
val TextAccent = Color(0xFF00F5FF)
