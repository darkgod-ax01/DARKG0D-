package com.example.data

import android.app.Activity
import android.view.WindowManager
import kotlinx.coroutines.flow.MutableStateFlow

object SecurityManager {
    val isAppLocked = MutableStateFlow(false)
    val isLockEnabled = MutableStateFlow(false)
    val lockType = MutableStateFlow("PIN") // "PIN", "Password", "Pattern"
    val lockPasscode = MutableStateFlow("1337") // Default passcode

    val intruderAttempts = MutableStateFlow(0)
    val intruderLogs = MutableStateFlow<List<String>>(emptyList())

    val isSecureModeEnabled = MutableStateFlow(true) // Screenshot Protection default active

    fun applySecureMode(activity: Activity?) {
        activity?.runOnUiThread {
            try {
                if (isSecureModeEnabled.value) {
                    activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun toggleSecureMode(activity: Activity?) {
        isSecureModeEnabled.value = !isSecureModeEnabled.value
        applySecureMode(activity)
    }

    fun handleWrongAttempt() {
        val attempts = intruderAttempts.value + 1
        intruderAttempts.value = attempts
        if (attempts >= 3) {
            val timestamp = java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss",
                java.util.Locale.getDefault()
            ).format(java.util.Date())
            val log = "Intruder attempt #$attempts detected - Failed Lock screen verification - $timestamp"
            intruderLogs.value = listOf(log) + intruderLogs.value
        }
    }

    fun resetAttempts() {
        intruderAttempts.value = 0
    }
}
