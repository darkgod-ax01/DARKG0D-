package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AmoledBlackColorScheme = darkColorScheme(
    primary = CyberCyan,
    secondary = CyberPink,
    tertiary = CyberGreen,
    background = CyberBlack,
    surface = CyberCard,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

private val CyberDarkColorScheme = darkColorScheme(
    primary = CyberPink,
    secondary = CyberCyan,
    tertiary = CyberAmber,
    background = CyberGrey,
    surface = CyberCard,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark
)

private val AmoledDarkColorScheme = darkColorScheme(
    primary = CyberAmber,
    secondary = CyberGreen,
    tertiary = CyberCyan,
    background = CyberBlack,
    surface = CyberGrey,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00838F), // Teal
    secondary = Color(0xFFAD1457), // Pink Accent
    background = Color(0xFFFAFAFA),
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color.Black,
    onSurface = Color.Black
)

@Composable
fun DarkBrowserTheme(
    themeMode: String = "AMOLED Black",
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        "AMOLED Black" -> AmoledBlackColorScheme
        "Cyber Dark" -> CyberDarkColorScheme
        "AMOLED Dark" -> AmoledDarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
