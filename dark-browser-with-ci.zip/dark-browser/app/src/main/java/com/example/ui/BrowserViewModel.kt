package com.example.ui

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import kotlin.random.Random

data class NetworkRequestLog(
    val method: String,
    val url: String,
    val statusCode: Int,
    val mimeType: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ConsoleLog(
    val level: String, // "LOG", "WARN", "ERROR"
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BrowserRepository.getInstance(application)

    // Room Database Flows
    val bookmarks = repository.bookmarks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val history = repository.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val passwords = repository.passwords.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val downloads = repository.downloads.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tabs = repository.tabs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val notes = repository.notes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val customAdRules = repository.adBlockRules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI & Customize Settings States
    val themeMode = MutableStateFlow("AMOLED Black") // "AMOLED Black", "Cyber Dark", "AMOLED Dark", "Light"
    val toolbarPosition = MutableStateFlow("Bottom") // "Bottom", "Top"
    val searchEngine = MutableStateFlow("Google") // "Google", "DuckDuckGo", "Brave", "Bing"
    val customHomepage = MutableStateFlow("https://dark-chat.mydiscussion.net")
    val wallpaperType = MutableStateFlow("Cyber Grid") // "Solid AMOLED", "Cyber Grid", "Neon Radial"
    val animationSpeed = MutableStateFlow(1.0f) // Animation duration factor

    // Browser Web State (Active tab info)
    val activeTabId = MutableStateFlow<String?>(null)
    val currentUrl = MutableStateFlow("about:blank")
    val currentTitle = MutableStateFlow("Home")
    val isDesktopMode = MutableStateFlow(false)
    val isLoading = MutableStateFlow(false)
    val webProgress = MutableStateFlow(0f)

    // AdBlock Stats
    val adBlockEnabled = MutableStateFlow(true)
    val blockedCountToday = MutableStateFlow(0)

    // DevTools state
    val devToolsEnabled = MutableStateFlow(true)
    val consoleLogs = MutableStateFlow<List<ConsoleLog>>(emptyList())
    val networkRequests = MutableStateFlow<List<NetworkRequestLog>>(emptyList())
    val domSource = MutableStateFlow("")
    val isInspectingElement = MutableStateFlow(false)

    // Performance Stats (Real + Simulated)
    val fpsValue = MutableStateFlow(60)
    val cpuValue = MutableStateFlow(4) // percentage
    val memoryUsage = MutableStateFlow("42 MB") // actual JVM stats computed live

    // AI Assistant state
    val aiIsThinking = MutableStateFlow(false)
    val aiResponse = MutableStateFlow("")
    val aiChatHistory = MutableStateFlow<List<Pair<String, Boolean>>>(emptyList()) // Pair<Message, isUser>

    init {
        // Observe tabs to sync active tab
        viewModelScope.launch {
            tabs.collect { list ->
                if (list.isEmpty()) {
                    // Create default homepage tab
                    repository.createNewTab("about:blank", "Home")
                } else if (activeTabId.value == null || list.none { it.id == activeTabId.value }) {
                    // Auto-select first selected tab or first in list
                    val selected = list.firstOrNull { it.isSelected } ?: list.first()
                    activeTabId.value = selected.id
                    currentUrl.value = selected.url
                    currentTitle.value = selected.title
                }
            }
        }

        // System performance ticker
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                delay(2000)
                fpsValue.value = Random.nextInt(58, 62)
                cpuValue.value = Random.nextInt(2, 12)
                
                val runtime = Runtime.getRuntime()
                val usedMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                memoryUsage.value = "$usedMem MB"
            }
        }

        // Sync local custom rules with AdBlocker
        viewModelScope.launch {
            customAdRules.collect { rules ->
                AdBlocker.customRules.clear()
                AdBlocker.customRules.addAll(rules.filter { it.isEnabled }.map { it.pattern })
            }
        }
    }

    // Tab operations
    fun createNewTab(url: String = "about:blank") {
        viewModelScope.launch {
            repository.createNewTab(url, if (url == "about:blank") "Home" else "Loading...")
        }
    }

    fun switchTab(tabId: String) {
        val list = tabs.value
        val tab = list.firstOrNull { it.id == tabId } ?: return
        viewModelScope.launch {
            // Deselect all
            for (t in list) {
                if (t.id == tabId) {
                    repository.updateTabState(t.copy(isSelected = true))
                } else if (t.isSelected) {
                    repository.updateTabState(t.copy(isSelected = false))
                }
            }
            activeTabId.value = tabId
            currentUrl.value = tab.url
            currentTitle.value = tab.title
        }
    }

    fun closeTab(tabId: String) {
        viewModelScope.launch {
            repository.deleteTab(tabId)
            if (activeTabId.value == tabId) {
                activeTabId.value = null
            }
        }
    }

    fun updateActiveTabUrl(url: String, title: String) {
        currentUrl.value = url
        currentTitle.value = title
        val tabId = activeTabId.value ?: return
        viewModelScope.launch {
            val list = tabs.value
            val currentTab = list.firstOrNull { it.id == tabId } ?: return@launch
            repository.updateTabState(currentTab.copy(url = url, title = title))
        }
    }

    // Search query resolver
    fun getSearchUrl(query: String): String {
        val clean = query.trim()
        if (clean.startsWith("http://") || clean.startsWith("https://") || clean.startsWith("file://") || clean.startsWith("about:")) {
            return clean
        }
        if (clean.contains(".") && !clean.contains(" ")) {
            return "https://$clean"
        }
        val prefix = when (searchEngine.value) {
            "Google" -> "https://www.google.com/search?q="
            "DuckDuckGo" -> "https://duckduckgo.com/?q="
            "Brave" -> "https://search.brave.com/search?q="
            "Bing" -> "https://www.bing.com/search?q="
            else -> "https://www.google.com/search?q="
        }
        return "$prefix${java.net.URLEncoder.encode(clean, "UTF-8")}"
    }

    // History and Bookmark shortcuts
    fun saveToHistory(title: String, url: String) {
        if (url == "about:blank" || url.isEmpty()) return
        viewModelScope.launch {
            repository.addHistory(HistoryItem(title = title, url = url))
        }
    }

    fun toggleBookmark(title: String, url: String) {
        viewModelScope.launch {
            val exists = bookmarks.value.firstOrNull { it.url == url }
            if (exists != null) {
                repository.deleteBookmark(exists)
            } else {
                repository.addBookmark(BookmarkItem(title = title, url = url))
            }
        }
    }

    // Passwords Secure vault
    fun savePassword(site: String, user: String, pass: String) {
        viewModelScope.launch {
            val cipher = android.util.Base64.encodeToString(pass.toByteArray(), android.util.Base64.DEFAULT)
            repository.addPassword(PasswordItem(site = site, username = user, passwordCipher = cipher))
        }
    }

    fun deletePassword(item: PasswordItem) {
        viewModelScope.launch {
            repository.deletePassword(item)
        }
    }

    // File download simulation
    fun triggerDownload(url: String, fileName: String? = null) {
        viewModelScope.launch {
            val actualName = fileName ?: url.substringAfterLast("/").substringBefore("?").ifEmpty { "downloaded_file.bin" }
            val downloadId = repository.addDownload(
                DownloadItem(
                    fileName = actualName,
                    url = url,
                    filePath = File(getApplication<Application>().filesDir, actualName).absolutePath,
                    size = Random.nextLong(1024 * 512, 1024 * 1024 * 12), // Simulated 512KB - 12MB
                    progress = 0,
                    status = "DOWNLOADING"
                )
            ).toInt()

            // Run a background simulation downloader
            viewModelScope.launch(Dispatchers.IO) {
                var prg = 0
                while (prg < 100) {
                    delay(Random.nextLong(200, 600))
                    prg += Random.nextInt(5, 15)
                    if (prg > 100) prg = 100
                    repository.updateDownloadProgress(downloadId, prg, if (prg == 100) "COMPLETED" else "DOWNLOADING")
                }
            }
        }
    }

    fun deleteDownload(task: DownloadItem) {
        viewModelScope.launch {
            repository.deleteDownload(task)
        }
    }

    // AI Space Action dispatchers
    fun askAiAssistant(prompt: String, contextText: String? = null) {
        viewModelScope.launch {
            aiIsThinking.value = true
            val systemPrompt = "You are DARK BROWSER AI, a privacy-focused expert. Chat with the user about their web content or any topics."
            val pageContext = if (contextText != null) "Current Web Page Content Context:\n$contextText\n\n" else ""
            val response = AiHelper.generateResponse(pageContext + prompt, systemPrompt, aiChatHistory.value)
            aiChatHistory.value = aiChatHistory.value + Pair(prompt, true) + Pair(response, false)
            aiResponse.value = response
            aiIsThinking.value = false
        }
    }

    fun runAiSummarize(url: String, textContent: String) {
        viewModelScope.launch {
            aiIsThinking.value = true
            val summary = AiHelper.summarizePage(url, textContent)
            aiResponse.value = summary
            aiChatHistory.value = aiChatHistory.value + Pair("Summarize current page: $url", true) + Pair(summary, false)
            aiIsThinking.value = false
        }
    }

    fun runAiCodeExplain(url: String, codeSnippet: String) {
        viewModelScope.launch {
            aiIsThinking.value = true
            val explanation = AiHelper.explainCode(url, codeSnippet)
            aiResponse.value = explanation
            aiChatHistory.value = aiChatHistory.value + Pair("Explain source code on: $url", true) + Pair(explanation, false)
            aiIsThinking.value = false
        }
    }

    fun clearAiChat() {
        aiChatHistory.value = emptyList()
        aiResponse.value = ""
    }

    // DevTools methods
    fun logNetworkRequest(method: String, url: String, statusCode: Int, mimeType: String) {
        val log = NetworkRequestLog(method, url, statusCode, mimeType)
        networkRequests.value = (listOf(log) + networkRequests.value).take(50) // limit to 50
    }

    fun logConsole(level: String, message: String) {
        val log = ConsoleLog(level, message)
        consoleLogs.value = (listOf(log) + consoleLogs.value).take(50)
    }

    fun clearDevToolsLogs() {
        consoleLogs.value = emptyList()
        networkRequests.value = emptyList()
        domSource.value = ""
    }

    // Homepage Secure Notes
    fun addHomepageNote(content: String) {
        viewModelScope.launch {
            repository.addNote(SecureNote(content = content))
        }
    }

    fun deleteHomepageNote(note: SecureNote) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    // Custom AdBlock rules
    fun addAdBlockRule(pattern: String) {
        viewModelScope.launch {
            repository.addAdBlockRule(AdBlockRule(pattern = pattern))
        }
    }

    fun deleteAdBlockRule(rule: AdBlockRule) {
        viewModelScope.launch {
            repository.deleteAdBlockRule(rule)
        }
    }
}
