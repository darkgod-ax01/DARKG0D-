package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BookmarkItem
import com.example.data.SecureNote
import com.example.data.VpnDnsProxyManager
import com.example.ui.BrowserViewModel

@Composable
fun DashboardHome(viewModel: BrowserViewModel, onNavigate: (String) -> Unit) {
    val bookmarks by viewModel.bookmarks.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val isVpnActive by VpnDnsProxyManager.isVpnConnected.collectAsState()
    val activeDns by VpnDnsProxyManager.selectedDns.collectAsState()
    val wallpaperType by viewModel.wallpaperType.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }

    // Cyberpunk canvas background
    val bgBrush = when (wallpaperType) {
        "Solid AMOLED" -> Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF000000)))
        "Neon Radial" -> Brush.radialGradient(listOf(Color(0xFF1F0918), Color(0xFF000000)))
        else -> Brush.verticalGradient(listOf(Color(0xFF0A0D14), Color(0xFF000000))) // Cyber Grid
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgBrush)
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Full width Search card
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF00F5FF))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "SECURE QUANTUM SEARCH",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search or input URL...", color = Color.Gray) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF00F5FF),
                                unfocusedBorderColor = Color(0xFF1E2235)
                            ),
                            trailingIcon = {
                                IconButton(onClick = {
                                    if (searchQuery.isNotEmpty()) {
                                        val url = viewModel.getSearchUrl(searchQuery)
                                        onNavigate(url)
                                        searchQuery = ""
                                    }
                                }) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Go", tint = Color(0xFF00F5FF))
                                }
                            }
                        )
                    }
                }
            }

            // Quick Access grid icons
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val quickLinks = listOf(
                        Triple("Google", "https://google.com", Icons.Default.Language),
                        Triple("Chat", "https://dark-chat.mydiscussion.net", Icons.Default.Chat),
                        Triple("GitHub", "https://github.com", Icons.Default.DeveloperMode),
                        Triple("YouTube", "https://youtube.com", Icons.Default.VideoLibrary)
                    )

                    quickLinks.forEach { link ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onNavigate(link.second) }
                                .padding(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = link.third,
                                    contentDescription = link.first,
                                    tint = Color(0xFF00F5FF),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                link.first,
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Simulated cyber weather diagnostics widget
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0B10)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.border(1.dp, Color(0xFF1E2235), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Cloud, contentDescription = null, tint = Color(0xFFFF007F), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("CYBER ATMOSPHERE", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("72°F NEON CITY", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("AQI: 12 - EXCELLENT", color = Color(0xFF39FF14), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // Security Engine Status widget
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0B10)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.border(1.dp, Color(0xFF1E2235), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SECURITY CORES", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(if (isVpnActive) "VPN ON" else "VPN OFF", color = if (isVpnActive) Color(0xFF39FF14) else Color(0xFFFF007F), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("DNS: $activeDns", color = Color.LightGray, fontSize = 10.sp, maxLines = 1, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // Bookmarks grid header
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                Text(
                    "QUICK ACCESS SECURE BOOKMARKS:",
                    color = Color(0xFF00F5FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (bookmarks.isEmpty()) {
                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No bookmarks saved. Press star icon in toolbar to save.", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }

            items(bookmarks, span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) { bookmark ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F111A))
                        .clickable { onNavigate(bookmark.url) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(bookmark.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(bookmark.url, color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                    }
                }
            }

            // Secure notes panel on home dashboard
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                Text(
                    "HOMEPAGE SECURED TEXT NOTES:",
                    color = Color(0xFF00F5FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.border(1.dp, Color(0xFF1E2235), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = noteInput,
                                onValueChange = { noteInput = it },
                                placeholder = { Text("Write secured note text...") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFF007F),
                                    unfocusedBorderColor = Color(0xFF1E2235)
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(onClick = {
                                if (noteInput.trim().isNotEmpty()) {
                                    viewModel.addHomepageNote(noteInput.trim())
                                    noteInput = ""
                                }
                            }) {
                                Icon(Icons.Default.AddComment, contentDescription = "Add", tint = Color(0xFFFF007F))
                            }
                        }

                        if (notes.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                notes.forEach { note ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF05060A), RoundedCornerShape(6.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(note.content, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                        IconButton(onClick = { viewModel.deleteHomepageNote(note) }) {
                                            Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
