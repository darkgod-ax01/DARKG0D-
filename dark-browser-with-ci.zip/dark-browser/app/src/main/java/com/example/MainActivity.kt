package com.example

import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.SecurityManager
import com.example.ui.BrowserViewModel
import com.example.ui.components.*
import com.example.ui.theme.DarkBrowserTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup secure layout mode initially if enabled
        SecurityManager.applySecureMode(this)
        
        enableEdgeToEdge()
        setContent {
            val viewModel: BrowserViewModel = viewModel()
            val activeTheme by viewModel.themeMode.collectAsState()

            DarkBrowserTheme(themeMode = activeTheme) {
                MainContainer(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Auto lock app on resume if lock is enabled
        if (SecurityManager.isLockEnabled.value) {
            SecurityManager.isAppLocked.value = true
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainer(viewModel: BrowserViewModel) {
    val isLockedState by SecurityManager.isAppLocked.collectAsState()
    val isLockEnabled by SecurityManager.isLockEnabled.collectAsState()

    if (isLockEnabled && isLockedState) {
        // App Lock Cover
        AppLockScreen(onUnlockSuccess = {
            SecurityManager.isAppLocked.value = false
        })
    } else {
        // Main App Layout
        var activeScreen by remember { mutableStateOf("BROWSER") } // "BROWSER", "NETWORK", "TOOLS", "AI", "SETTINGS"
        var showTabsSheet by remember { mutableStateOf(false) }
        var showDevToolsSheet by remember { mutableStateOf(false) }

        val currentUrl by viewModel.currentUrl.collectAsState()
        val currentTitle by viewModel.currentTitle.collectAsState()
        val isLoading by viewModel.isLoading.collectAsState()
        val webProgress by viewModel.webProgress.collectAsState()
        val isDesktopMode by viewModel.isDesktopMode.collectAsState()
        val toolbarPosition by viewModel.toolbarPosition.collectAsState()
        val adBlockEnabled by viewModel.adBlockEnabled.collectAsState()
        val totalBlockedToday by viewModel.blockedCountToday.collectAsState()

        val tabsList by viewModel.tabs.collectAsState()
        val activeTabId by viewModel.activeTabId.collectAsState()

        var webViewRef by remember { mutableStateOf<WebView?>(null) }
        var inputAddressUrl by remember { mutableStateOf(currentUrl) }

        // Sync inputAddress with url changes
        LaunchedEffect(currentUrl) {
            inputAddressUrl = if (currentUrl == "about:blank") "" else currentUrl
        }

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            bottomBar = {
                if (toolbarPosition == "Bottom") {
                    NavigationBarLayout(
                        activeScreen = activeScreen,
                        onScreenChange = { activeScreen = it },
                        totalBlocked = totalBlockedToday,
                        adBlockActive = adBlockEnabled
                    )
                }
            },
            topBar = {
                if (toolbarPosition == "Top") {
                    NavigationBarLayout(
                        activeScreen = activeScreen,
                        onScreenChange = { activeScreen = it },
                        totalBlocked = totalBlockedToday,
                        adBlockActive = adBlockEnabled
                    )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(Color.Black)
            ) {
                // Main Application Core Router
                Box(modifier = Modifier.weight(1f)) {
                    when (activeScreen) {
                        "BROWSER" -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Dynamic Address Bar Input (if we are in browser view)
                                AddressToolbar(
                                    urlValue = inputAddressUrl,
                                    onUrlValueChange = { inputAddressUrl = it },
                                    currentTitle = currentTitle,
                                    isDesktop = isDesktopMode,
                                    isLoading = isLoading,
                                    isHomepage = currentUrl == "about:blank",
                                    progress = webProgress,
                                    onGoClick = {
                                        if (inputAddressUrl.isNotEmpty()) {
                                            val dest = viewModel.getSearchUrl(inputAddressUrl)
                                            viewModel.updateActiveTabUrl(dest, "Loading...")
                                            webViewRef?.loadUrl(dest)
                                        }
                                    },
                                    onTabsClick = { showTabsSheet = true },
                                    onDevToolsClick = { showDevToolsSheet = true },
                                    onDesktopToggle = { viewModel.isDesktopMode.value = !isDesktopMode },
                                    onHomeClick = {
                                        viewModel.updateActiveTabUrl("about:blank", "Home")
                                        webViewRef?.loadUrl("about:blank")
                                    },
                                    onBackClick = { if (webViewRef?.canGoBack() == true) webViewRef?.goBack() },
                                    onForwardClick = { if (webViewRef?.canGoForward() == true) webViewRef?.goForward() },
                                    onRefreshClick = { webViewRef?.reload() },
                                    onBookmarkToggle = { viewModel.toggleBookmark(currentTitle, currentUrl) }
                                )

                                Box(modifier = Modifier.weight(1f)) {
                                    if (currentUrl == "about:blank") {
                                        DashboardHome(viewModel = viewModel, onNavigate = { url ->
                                            viewModel.updateActiveTabUrl(url, "Loading...")
                                            webViewRef?.loadUrl(url)
                                        })
                                    } else {
                                        BrowserWebView(viewModel = viewModel, onWebViewCreated = { webView ->
                                            webViewRef = webView
                                        })
                                    }
                                }
                            }
                        }
                        "NETWORK" -> NetworkHub()
                        "TOOLS" -> SecurityTools(viewModel)
                        "AI" -> AiAssistantHub(viewModel)
                        "SETTINGS" -> SettingsHub(viewModel)
                    }
                }
            }
        }

        // Unlimited Tabs Manager Dialog Bottom Sheet
        if (showTabsSheet) {
            AlertDialog(
                onDismissRequest = { showTabsSheet = false },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "VERTICAL MULTI-TABS",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(onClick = {
                            viewModel.createNewTab()
                            showTabsSheet = false
                        }) {
                            Icon(Icons.Default.AddCircle, contentDescription = "New Tab", tint = Color(0xFF00F5FF))
                        }
                    }
                },
                containerColor = Color(0xFF0D0E15),
                shape = RoundedCornerShape(16.dp),
                text = {
                    Column {
                        var tabSearchQuery by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = tabSearchQuery,
                            onValueChange = { tabSearchQuery = it },
                            placeholder = { Text("Search open tabs...") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF00F5FF),
                                unfocusedBorderColor = Color(0xFF1E2235)
                            )
                        )

                        LazyColumn(modifier = Modifier.height(300.dp)) {
                            val filteredTabs = if (tabSearchQuery.isEmpty()) {
                                tabsList
                            } else {
                                tabsList.filter { it.title.contains(tabSearchQuery, ignoreCase = true) || it.url.contains(tabSearchQuery, ignoreCase = true) }
                            }

                            items(filteredTabs) { tab ->
                                val isActive = tab.id == activeTabId
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(if (isActive) Color(0xFF1E2235) else Color(0xFF0F111A), RoundedCornerShape(8.dp))
                                        .clickable {
                                            viewModel.switchTab(tab.id)
                                            showTabsSheet = false
                                        }
                                        .padding(12.dp)
                                        .border(1.dp, if (isActive) Color(0xFF00F5FF) else Color.Transparent, RoundedCornerShape(8.dp)),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Tab, contentDescription = null, tint = if (isActive) Color(0xFF00F5FF) else Color.Gray)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(tab.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text(tab.url, color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                                    }
                                    if (tabsList.size > 1) {
                                        IconButton(onClick = { viewModel.closeTab(tab.id) }) {
                                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Red, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showTabsSheet = false }) {
                        Text("CLOSE", color = Color(0xFFFF007F), fontFamily = FontFamily.Monospace)
                    }
                }
            )
        }

        // Developer tools Bottom Sheet Dialog
        if (showDevToolsSheet) {
            AlertDialog(
                onDismissRequest = { showDevToolsSheet = false },
                title = {
                    Text(
                        text = "DESKTOP-CLASS DEVTOOLS",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                },
                containerColor = Color(0xFF0D0E15),
                shape = RoundedCornerShape(16.dp),
                text = {
                    Box(modifier = Modifier.height(400.dp)) {
                        DevToolsPanel(viewModel)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showDevToolsSheet = false }) {
                        Text("CLOSE DEVTOOLS", color = Color(0xFFFF007F), fontFamily = FontFamily.Monospace)
                    }
                }
            )
        }
    }
}

@Composable
fun AddressToolbar(
    urlValue: String,
    onUrlValueChange: (String) -> Unit,
    currentTitle: String,
    isDesktop: Boolean,
    isLoading: Boolean,
    isHomepage: Boolean,
    progress: Float,
    onGoClick: () -> Unit,
    onTabsClick: () -> Unit,
    onDevToolsClick: () -> Unit,
    onDesktopToggle: () -> Unit,
    onHomeClick: () -> Unit,
    onBackClick: () -> Unit,
    onForwardClick: () -> Unit,
    onRefreshClick: () -> Unit,
    onBookmarkToggle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0D0E15))
            .border(1.dp, Color(0xFF1E2235))
    ) {
        // Navigation Arrow controls + Home Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                IconButton(onClick = onForwardClick) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "Forward", tint = Color.White)
                }
                IconButton(onClick = onRefreshClick) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = Color.White)
                }
                IconButton(onClick = onHomeClick) {
                    Icon(Icons.Default.Home, contentDescription = "Homepage", tint = Color(0xFF00F5FF))
                }
            }

            Row {
                IconButton(onClick = onBookmarkToggle) {
                    Icon(Icons.Default.StarBorder, contentDescription = "Star", tint = Color(0xFFFFB300))
                }
                IconButton(onClick = onDesktopToggle) {
                    Icon(
                        imageVector = if (isDesktop) Icons.Default.Laptop else Icons.Default.Smartphone,
                        contentDescription = "Desktop mode",
                        tint = if (isDesktop) Color(0xFF00F5FF) else Color.White
                    )
                }
                IconButton(onClick = onDevToolsClick) {
                    Icon(Icons.Default.DeveloperMode, contentDescription = "DevTools", tint = Color(0xFFFF007F))
                }
            }
        }

        // URL Input Bar (only shown when not inside the Home screen dashboard, or can act as general url bar)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .background(Color(0xFF05060A), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Lock, contentDescription = "Secure", tint = Color(0xFF39FF14), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))

            OutlinedTextField(
                value = urlValue,
                onValueChange = onUrlValueChange,
                placeholder = { Text("Browse cyber network...", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                ),
                modifier = Modifier.weight(1f),
                singleLine = true,
                trailingIcon = {
                    if (urlValue.isNotEmpty()) {
                        IconButton(onClick = onGoClick) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Go", tint = Color(0xFF00F5FF))
                        }
                    }
                }
            )

            // Unlimited Tabs Selector
            IconButton(onClick = onTabsClick) {
                Icon(Icons.Default.Layers, contentDescription = "Tabs", tint = Color(0xFF00F5FF))
            }
        }

        // Web progress line
        if (isLoading) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Color(0xFF00F5FF),
                trackColor = Color.Transparent
            )
        }
    }
}

@Composable
fun NavigationBarLayout(
    activeScreen: String,
    onScreenChange: (String) -> Unit,
    totalBlocked: Int,
    adBlockActive: Boolean
) {
    NavigationBar(
        containerColor = Color(0xFF0D0E15),
        tonalElevation = 8.dp,
        modifier = Modifier.border(1.dp, Color(0xFF1E2235))
    ) {
        val navItems = listOf(
            Triple("BROWSER", Icons.Default.Language, "Browser"),
            Triple("NETWORK", Icons.Default.Security, "Network"),
            Triple("TOOLS", Icons.Default.Construction, "Tools"),
            Triple("AI", Icons.Default.Hub, "AI Chat"),
            Triple("SETTINGS", Icons.Default.Settings, "Config")
        )

        navItems.forEach { item ->
            val isSelected = activeScreen == item.first
            NavigationBarItem(
                selected = isSelected,
                onClick = { onScreenChange(item.first) },
                icon = {
                    Box {
                        Icon(
                            imageVector = item.second,
                            contentDescription = item.third,
                            tint = if (isSelected) Color(0xFF00F5FF) else Color.Gray
                        )
                        // Show tiny green AdBlock Shield badge on BROWSER tab if active
                        if (item.first == "BROWSER" && adBlockActive && totalBlocked > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 10.dp, y = (-4).dp)
                                    .background(Color(0xFF39FF14), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = totalBlocked.toString(),
                                    color = Color.Black,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                label = {
                    Text(
                        text = item.third,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color(0xFF00F5FF) else Color.Gray,
                        fontFamily = FontFamily.Monospace
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Color(0xFF1E2235)
                )
            )
        }
    }
}
