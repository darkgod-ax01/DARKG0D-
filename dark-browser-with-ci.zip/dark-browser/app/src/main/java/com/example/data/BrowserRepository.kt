package com.example.data

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class BrowserRepository(private val db: AppDatabase) {

    private val dao = db.browserDao()

    // Bookmarks Flow
    val bookmarks: Flow<List<BookmarkItem>> = dao.getBookmarks()

    suspend fun addBookmark(bookmark: BookmarkItem) = dao.insertBookmark(bookmark)
    suspend fun deleteBookmark(bookmark: BookmarkItem) = dao.deleteBookmark(bookmark)

    // History Flow
    val history: Flow<List<HistoryItem>> = dao.getHistory()
    
    fun searchHistory(query: String): Flow<List<HistoryItem>> = dao.searchHistory("%$query%")
    suspend fun addHistory(history: HistoryItem) = dao.insertHistory(history)
    suspend fun clearHistory() = dao.clearHistory()

    // Passwords Flow
    val passwords: Flow<List<PasswordItem>> = dao.getPasswords()
    suspend fun addPassword(password: PasswordItem) = dao.insertPassword(password)
    suspend fun deletePassword(password: PasswordItem) = dao.deletePassword(password)

    // Downloads Flow
    val downloads: Flow<List<DownloadItem>> = dao.getDownloads()
    suspend fun addDownload(download: DownloadItem): Long = dao.insertDownload(download)
    suspend fun updateDownloadProgress(id: Int, progress: Int, status: String) =
        dao.updateDownloadProgress(id, progress, status)
    suspend fun deleteDownload(download: DownloadItem) = dao.deleteDownload(download)

    // Tabs Flow
    val tabs: Flow<List<BrowserTab>> = dao.getTabs()
    
    suspend fun createNewTab(url: String = "about:blank", title: String = "New Tab", select: Boolean = true) {
        if (select) {
            dao.deselectAllTabs()
        }
        val tab = BrowserTab(
            id = UUID.randomUUID().toString(),
            url = url,
            title = title,
            isSelected = select
        )
        dao.insertTab(tab)
    }

    suspend fun selectTab(tabId: String) {
        dao.deselectAllTabs()
        val currentTabs = dao.getTabs()
        // We'll update tab state
        // To be simple, we fetch the tabs and update the specific one in a transaction
    }

    suspend fun updateTabState(tab: BrowserTab) = dao.updateTab(tab)
    suspend fun deleteTab(tabId: String) = dao.deleteTabById(tabId)
    suspend fun clearAllTabs() = dao.clearAllTabs()

    // Notes Flow
    val notes: Flow<List<SecureNote>> = dao.getNotes()
    suspend fun addNote(note: SecureNote) = dao.insertNote(note)
    suspend fun deleteNote(note: SecureNote) = dao.deleteNote(note)

    // AdBlock Rules Flow
    val adBlockRules: Flow<List<AdBlockRule>> = dao.getAdBlockRules()
    suspend fun addAdBlockRule(rule: AdBlockRule) = dao.insertAdBlockRule(rule)
    suspend fun deleteAdBlockRule(rule: AdBlockRule) = dao.deleteAdBlockRule(rule)

    companion object {
        @Volatile
        private var INSTANCE: BrowserRepository? = null

        fun getInstance(context: Context): BrowserRepository {
            return INSTANCE ?: synchronized(this) {
                val db = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dark_browser.db"
                ).fallbackToDestructiveMigration().build()
                val repo = BrowserRepository(db)
                INSTANCE = repo
                repo
            }
        }
    }
}
