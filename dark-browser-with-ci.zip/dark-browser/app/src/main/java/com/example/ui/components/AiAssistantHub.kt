package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BrowserViewModel
import kotlinx.coroutines.launch

@Composable
fun AiAssistantHub(viewModel: BrowserViewModel) {
    val chatHistory by viewModel.aiChatHistory.collectAsState()
    val isThinking by viewModel.aiIsThinking.collectAsState()
    val currentUrl by viewModel.currentUrl.collectAsState()
    val domSource by viewModel.domSource.collectAsState()

    var userPrompt by remember { mutableStateOf("") }
    val lazyListState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    var showTranslateSheet by remember { mutableStateOf(false) }
    val languages = listOf("Spanish", "French", "German", "Chinese", "Japanese", "Hindi", "Russian", "Arabic")

    // Auto-scroll to the bottom when history grows
    LaunchedEffect(chatHistory.size) {
        if (chatHistory.isNotEmpty()) {
            lazyListState.animateScrollToItem(chatHistory.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
    ) {
        // AI Header banner
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
            shape = RoundedCornerShape(0.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E2235))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Hub,
                        contentDescription = "AI Space",
                        tint = Color(0xFF00F5FF),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "DARK BROWSER AI TERMINAL",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "MODEL: gemini-3.5-flash",
                            color = Color.Gray,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Context Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Summarize current page
                    Button(
                        onClick = {
                            val plainText = domSource.replace(Regex("<[^>]*>"), " ").trim().take(3000)
                            viewModel.runAiSummarize(currentUrl, plainText)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F111A)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        modifier = Modifier.weight(1f).border(1.dp, Color(0xFF1E2235), RoundedCornerShape(8.dp))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Summarize, contentDescription = null, tint = Color(0xFF00F5FF), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SUMMARIZE", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Explain page code
                    Button(
                        onClick = {
                            val codeExcerpt = domSource.take(1500)
                            viewModel.runAiCodeExplain(currentUrl, codeExcerpt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F111A)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        modifier = Modifier.weight(1f).border(1.dp, Color(0xFF1E2235), RoundedCornerShape(8.dp))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFFFF007F), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("EXPLAIN CODE", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Translate content
                    Button(
                        onClick = { showTranslateSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F111A)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        modifier = Modifier.weight(1f).border(1.dp, Color(0xFF1E2235), RoundedCornerShape(8.dp))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Translate, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("TRANSLATE", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Chat logs body
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            if (chatHistory.isEmpty()) {
                // Empty Welcome Space
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "READY FOR QUERIES...",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Type in prompts or tap summarize to compile facts about the active page.",
                        fontSize = 11.sp,
                        color = Color.DarkGray,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        lineHeight = 16.sp
                    )
                }
            } else {
                LazyColumn(
                    state = lazyListState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(chatHistory) { message ->
                        val isUser = message.second
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(
                                        RoundedCornerShape(
                                            topStart = 12.dp,
                                            topEnd = 12.dp,
                                            bottomStart = if (isUser) 12.dp else 0.dp,
                                            bottomEnd = if (isUser) 0.dp else 12.dp
                                        )
                                    )
                                    .background(
                                        if (isUser) Color(0xFF1E2235) else Color(0xFF0F111A)
                                    )
                                    .border(
                                        1.dp,
                                        if (isUser) Color(0xFF00F5FF).copy(alpha = 0.5f) else Color(0xFFFF007F).copy(alpha = 0.3f),
                                        RoundedCornerShape(
                                            topStart = 12.dp,
                                            topEnd = 12.dp,
                                            bottomStart = if (isUser) 12.dp else 0.dp,
                                            bottomEnd = if (isUser) 0.dp else 12.dp
                                        )
                                    )
                                    .padding(12.dp)
                                    .widthIn(max = 280.dp)
                            ) {
                                Column {
                                    Text(
                                        text = if (isUser) "YOU" else "DARK AI",
                                        color = if (isUser) Color(0xFF00F5FF) else Color(0xFFFF007F),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = message.first,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Thinking Overlay
            if (isThinking) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.border(1.dp, Color(0xFFFF007F), RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(color = Color(0xFFFF007F), modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = "AI DECODING IN PROGRESS...",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Prompt Input Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.clearAiChat() }) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Clear", tint = Color.Gray)
            }

            OutlinedTextField(
                value = userPrompt,
                onValueChange = { userPrompt = it },
                placeholder = { Text("Ask secure AI companion...", color = Color.Gray, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                ),
                modifier = Modifier.weight(1f),
                singleLine = true
            )

            IconButton(
                onClick = {
                    if (userPrompt.trim().isNotEmpty()) {
                        val prompt = userPrompt.trim()
                        userPrompt = ""
                        viewModel.askAiAssistant(prompt)
                    }
                },
                enabled = userPrompt.trim().isNotEmpty()
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = if (userPrompt.trim().isNotEmpty()) Color(0xFF00F5FF) else Color.Gray
                )
            }
        }

        // Translation Sheet Dialog
        if (showTranslateSheet) {
            AlertDialog(
                onDismissRequest = { showTranslateSheet = false },
                title = { Text("SELECT TARGET TRANSLATION", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace) },
                containerColor = Color(0xFF0D0E15),
                shape = RoundedCornerShape(16.dp),
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Translate the current webpage content excerpt into one of the available target dialects:", color = Color.Gray, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyColumn(modifier = Modifier.height(200.dp)) {
                            items(languages) { lang ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF0F111A), RoundedCornerShape(8.dp))
                                        .clickable {
                                            showTranslateSheet = false
                                            val excerpt = domSource.replace(Regex("<[^>]*>"), " ").trim().take(1200)
                                            coroutineScope.launch {
                                                viewModel.aiIsThinking.value = true
                                                val res = com.example.data.AiHelper.translateContent(excerpt, lang)
                                                viewModel.aiChatHistory.value = viewModel.aiChatHistory.value +
                                                        Pair("Translate current page to $lang", true) + Pair(res, false)
                                                viewModel.aiResponse.value = res
                                                viewModel.aiIsThinking.value = false
                                            }
                                        }
                                        .padding(12.dp)
                                ) {
                                    Text(lang, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showTranslateSheet = false }) {
                        Text("CLOSE", color = Color(0xFFFF007F), fontFamily = FontFamily.Monospace)
                    }
                }
            )
        }
    }
}
