package com.example.data

import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import java.util.regex.Pattern

object AdBlocker {
    private val adDomains = hashSetOf(
        "doubleclick.net", "googleadservices.com", "googlesyndication.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "moatads.com",
        "pubmatic.com", "rubiconproject.com", "outbrain.com", "taboola.com",
        "adcolony.com", "applovin.com", "unityads.unity3d.com", "admob.com",
        "popads.net", "propellerads.com", "exoclick.com", "juicyads.com",
        "advertising.com", "quantserve.com", "scorecardresearch.com"
    )

    private val adPatterns = listOf(
        Pattern.compile("/ads/.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile("/banners?/.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile("/popups?/.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile("/adframe.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile("/trackers?/.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*\\?.*utm_source=.*", Pattern.CASE_INSENSITIVE)
    )

    var customRules = mutableStateListOf<String>()
    var totalBlockedCount = 0

    fun shouldBlock(url: String): Boolean {
        val uri = try { Uri.parse(url) } catch (e: Exception) { return false }
        val host = uri.host ?: return false

        // Check host
        for (adDomain in adDomains) {
            if (host.endsWith(adDomain) || host == adDomain) {
                totalBlockedCount++
                return true
            }
        }

        // Check path & query patterns
        val pathAndQuery = (uri.path ?: "") + (uri.query ?: "")
        for (pattern in adPatterns) {
            if (pattern.matcher(pathAndQuery).find()) {
                totalBlockedCount++
                return true
            }
        }

        // Check custom rules
        for (rule in customRules) {
            if (rule.isNotEmpty() && url.contains(rule, ignoreCase = true)) {
                totalBlockedCount++
                return true
            }
        }

        return false
    }
}
