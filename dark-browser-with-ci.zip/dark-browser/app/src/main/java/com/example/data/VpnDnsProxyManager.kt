package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import kotlin.random.Random

data class VpnServer(
    val id: String,
    val name: String,
    val countryCode: String,
    val ipAddress: String,
    val ping: Int,
    val isPremium: Boolean,
    val flag: String
)

data class DnsServer(
    val name: String,
    val address: String,
    val protocol: String, // "DoH", "DoT", "DoQ"
    val isRecommended: Boolean,
    val securityAnalysis: String,
    var pingResult: Int? = null
)

data class ProxyProfile(
    val name: String,
    val host: String,
    val port: Int,
    val type: String, // "HTTP", "HTTPS", "SOCKS4", "SOCKS5"
    val username: String? = null,
    val password: String? = null,
    val isActive: Boolean = false,
    var latency: Int? = null,
    var health: String = "Unknown" // "Healthy", "Dead", "Unknown"
)

object VpnDnsProxyManager {

    val vpnServers = listOf(
        VpnServer("in", "India", "IN", "103.241.140.2", 42, false, "🇮🇳"),
        VpnServer("sg", "Singapore", "SG", "128.199.210.5", 35, false, "🇸🇬"),
        VpnServer("jp", "Japan", "JP", "210.140.10.12", 68, true, "🇯🇵"),
        VpnServer("de", "Germany", "DE", "46.101.240.55", 112, false, "🇩🇪"),
        VpnServer("fr", "France", "FR", "195.154.122.99", 124, true, "🇫🇷"),
        VpnServer("uk", "United Kingdom", "GB", "82.165.101.44", 115, true, "🇬🇧"),
        VpnServer("us", "United States", "US", "104.244.72.1", 145, false, "🇺🇸"),
        VpnServer("ca", "Canada", "CA", "198.50.220.12", 152, true, "🇨🇦"),
        VpnServer("au", "Australia", "AU", "13.236.12.8", 185, true, "🇦🇺")
    )

    val dnsServers = listOf(
        DnsServer("Cloudflare DNS", "1.1.1.1", "DoH", true, "Enterprise Privacy, High Speed, DNSSEC enabled"),
        DnsServer("Google DNS", "8.8.8.8", "DoH", true, "Global coverage, extremely reliable, safety filtering"),
        DnsServer("Quad9 DNS", "9.9.9.9", "DoT", true, "Malware Blocking, Threat Intelligence, High Privacy"),
        DnsServer("AdGuard DNS", "94.140.14.14", "DoH", false, "Ad-Blocking, Tracker Blocking, Adult filters"),
        DnsServer("OpenDNS", "208.67.222.222", "DoH", false, "Custom filtering, parental controls, safe search"),
        DnsServer("NextDNS", "dns.nextdns.io", "DoQ", false, "Advanced firewall, highly customizable rules")
    )

    // Current VPN state
    val isVpnConnected = MutableStateFlow(false)
    val selectedVpnServer = MutableStateFlow(vpnServers[1]) // Default SG
    val vpnSentBytes = MutableStateFlow(0L)
    val vpnReceivedBytes = MutableStateFlow(0L)
    val vpnSpeed = MutableStateFlow("0.0 Mbps")
    val vpnConnectedTime = MutableStateFlow(0) // seconds

    // Current DNS state
    val selectedDns = MutableStateFlow(dnsServers[0]) // Default Cloudflare
    val dnsProtocol = MutableStateFlow("DoH") // "DoH", "DoT", "DoQ"
    val customDnsAddress = MutableStateFlow("")

    // Current Proxy State
    val proxyProfiles = MutableStateFlow(
        listOf(
            ProxyProfile("Default HTTP", "127.0.0.1", 8080, "HTTP"),
            ProxyProfile("Secure SOCKS5", "socks.darkbrowser.net", 1080, "SOCKS5", "daksh", "cyberdark")
        )
    )
    val activeProxyIndex = MutableStateFlow(-1) // -1 means no proxy

    init {
        // Start simulated VPN data generation if active
        kotlinx.coroutines.GlobalScope.launch(Dispatchers.IO) {
            while (true) {
                if (isVpnConnected.value) {
                    vpnConnectedTime.value += 1
                    val sentDiff = Random.nextLong(1024, 15360)
                    val recvDiff = Random.nextLong(10240, 153600)
                    vpnSentBytes.value += sentDiff
                    vpnReceivedBytes.value += recvDiff
                    vpnSpeed.value = String.format("%.2f Mbps", Random.nextDouble(5.0, 48.0))
                }
                delay(1000)
            }
        }
    }

    suspend fun runDnsBenchmark(): List<DnsServer> = withContext(Dispatchers.IO) {
        val list = dnsServers.map { it.copy() }
        for (server in list) {
            delay(150) // Simulate some work
            server.pingResult = when (server.name) {
                "Cloudflare DNS" -> Random.nextInt(12, 28)
                "Google DNS" -> Random.nextInt(18, 35)
                "Quad9 DNS" -> Random.nextInt(25, 45)
                "AdGuard DNS" -> Random.nextInt(32, 60)
                "OpenDNS" -> Random.nextInt(28, 55)
                else -> Random.nextInt(45, 85)
            }
        }
        return@withContext list.sortedBy { it.pingResult ?: 999 }
    }

    suspend fun runProxyTest(index: Int) = withContext(Dispatchers.IO) {
        val currentList = proxyProfiles.value.toMutableList()
        if (index in currentList.indices) {
            val profile = currentList[index]
            profile.latency = null
            profile.health = "Testing..."
            proxyProfiles.value = currentList.toList()
            delay(800) // Simulate proxy handshake

            val mockLatency = Random.nextInt(45, 280)
            val mockHealth = if (Random.nextFloat() > 0.15f) "Healthy" else "Dead"

            currentList[index] = profile.copy(latency = mockLatency, health = mockHealth)
            proxyProfiles.value = currentList.toList()
        }
    }

    fun toggleVpn() {
        val current = isVpnConnected.value
        isVpnConnected.value = !current
        if (!current) {
            vpnSentBytes.value = 0L
            vpnReceivedBytes.value = 0L
            vpnConnectedTime.value = 0
            vpnSpeed.value = "Connecting..."
        } else {
            vpnSpeed.value = "0.0 Mbps"
        }
    }
}
