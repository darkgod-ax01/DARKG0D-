package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.AdBlocker
import com.example.ui.BrowserViewModel
import java.io.ByteArrayInputStream

@SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
@Composable
fun BrowserWebView(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier,
    onWebViewCreated: (WebView) -> Unit = {}
) {
    val currentUrl by viewModel.currentUrl.collectAsState()
    val isDesktopMode by viewModel.isDesktopMode.collectAsState()
    val adBlockEnabled by viewModel.adBlockEnabled.collectAsState()

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                layoutParams = android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                )

                // WebView Settings
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    allowFileAccess = true
                    builtInZoomControls = true
                    displayZoomControls = false
                    cacheMode = WebSettings.LOAD_DEFAULT
                    mediaPlaybackRequiresUserGesture = false
                }

                // Custom Javascript Logger Interface for DevTools
                addJavascriptInterface(object {
                    @JavascriptInterface
                    fun logConsole(level: String, message: String) {
                        viewModel.logConsole(level, message)
                    }

                    @JavascriptInterface
                    fun logHtml(html: String) {
                        viewModel.domSource.value = html
                    }
                }, "DarkBrowserLog")

                // WebViewClient (interception & blocking)
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {
                        val url = request?.url?.toString() ?: ""
                        // Support custom URL schemes or prevent third-party redirects
                        if (url.startsWith("http://") || url.startsWith("https://")) {
                            return false
                        }
                        return true
                    }

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                        viewModel.isLoading.value = true
                        viewModel.webProgress.value = 0.1f
                        if (url != null) {
                            viewModel.currentUrl.value = url
                        }
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        viewModel.isLoading.value = false
                        viewModel.webProgress.value = 1f
                        if (url != null) {
                            val title = view?.title ?: "Page Info"
                            viewModel.updateActiveTabUrl(url, title)
                            viewModel.saveToHistory(title, url)

                            // Capture outerHTML for developer DOM Inspector
                            view?.evaluateJavascript(
                                "window.DarkBrowserLog.logHtml(document.documentElement.outerHTML);",
                                null
                            )
                        }
                    }

                    // EasyList / Custom ad intercept rule execution
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val url = request?.url?.toString() ?: ""
                        
                        // Check if request is ad tracker and if adblocker is active
                        if (adBlockEnabled && AdBlocker.shouldBlock(url)) {
                            // Increment today's blocks count in viewmodel
                            viewModel.blockedCountToday.value = AdBlocker.totalBlockedCount
                            
                            // Log blocked requests in network tab
                            viewModel.logNetworkRequest(
                                request?.method ?: "GET",
                                url,
                                403,
                                "BLOCKED (AdBlocker)"
                            )

                            // Return empty response to simulate blocking
                            return WebResourceResponse(
                                "text/plain",
                                "utf-8",
                                ByteArrayInputStream("".toByteArray())
                            )
                        }

                        // Log standard network requests for DevTools
                        val method = request?.method ?: "GET"
                        val headers = request?.requestHeaders ?: emptyMap()
                        val mimeType = when {
                            url.endsWith(".js") -> "application/javascript"
                            url.endsWith(".css") -> "text/css"
                            url.endsWith(".png") -> "image/png"
                            url.endsWith(".jpg") || url.endsWith(".jpeg") -> "image/jpeg"
                            else -> "text/html"
                        }
                        viewModel.logNetworkRequest(method, url, 200, mimeType)

                        return super.shouldInterceptRequest(view, request)
                    }
                }

                // WebChromeClient (progress & console capture)
                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        super.onProgressChanged(view, newProgress)
                        viewModel.webProgress.value = newProgress / 100f
                        if (newProgress == 100) {
                            viewModel.isLoading.value = false
                        }
                    }

                    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                        val level = when (consoleMessage?.messageLevel()) {
                            ConsoleMessage.MessageLevel.ERROR -> "ERROR"
                            ConsoleMessage.MessageLevel.WARNING -> "WARN"
                            else -> "LOG"
                        }
                        viewModel.logConsole(
                            level,
                            "[Console] ${consoleMessage?.message() ?: ""} (Line ${consoleMessage?.lineNumber()} in ${consoleMessage?.sourceId()})"
                        )
                        return true
                    }
                }

                onWebViewCreated(this)
            }
        },
        update = { webView ->
            // Update User Agent based on desktop vs mobile setting
            val desktopUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            val defaultUserAgent = webView.settings.userAgentString
            
            val currentUA = if (isDesktopMode) desktopUserAgent else null
            if (webView.settings.userAgentString != currentUA && currentUA != null) {
                webView.settings.userAgentString = currentUA
            } else if (currentUA == null) {
                webView.settings.userAgentString = null // Reset to default
            }

            // Sync URL navigation
            if (currentUrl != "about:blank" && webView.url != currentUrl) {
                webView.loadUrl(currentUrl)
            }
        }
    )
}
