package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AdBlockRule
import com.example.data.PasswordItem
import com.example.data.DownloadItem
import com.example.ui.BrowserViewModel
import kotlin.random.Random

@Composable
fun SecurityTools(viewModel: BrowserViewModel) {
    var toolTab by remember { mutableStateOf("VAULT") } // "VAULT", "ADBLOCK", "DOWNLOADS"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
    ) {
        // Headers selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            val tabs = listOf("VAULT", "ADBLOCK", "DOWNLOADS")
            for (tab in tabs) {
                val isSelected = toolTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF1E2235) else Color.Transparent)
                        .clickable { toolTab = tab }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (tab == "VAULT") "PASS VAULT" else tab,
                        color = if (isSelected) Color(0xFF00F5FF) else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (toolTab) {
                "VAULT" -> PasswordVaultContent(viewModel)
                "ADBLOCK" -> AdBlockRulesContent(viewModel)
                "DOWNLOADS" -> DownloadsContent(viewModel)
            }
        }
    }
}

@Composable
fun PasswordVaultContent(viewModel: BrowserViewModel) {
    val passwords by viewModel.passwords.collectAsState()
    
    var siteInput by remember { mutableStateOf("") }
    var userInput by remember { mutableStateOf("") }
    var passInput by remember { mutableStateOf("") }

    // Password generator states
    var genLength by remember { mutableStateOf(16f) }
    var includeSymbols by remember { mutableStateOf(true) }
    var includeNumbers by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Password Generator Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Password, contentDescription = null, tint = Color(0xFFFF007F))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("CYBER PASSWORDS GENERATOR", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("LENGTH: ${genLength.toInt()} CHARACTERS", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Slider(
                        value = genLength,
                        onValueChange = { genLength = it },
                        valueRange = 8f..32f,
                        colors = SliderDefaults.colors(activeTrackColor = Color(0xFFFF007F), thumbColor = Color(0xFFFF007F))
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = includeSymbols, onCheckedChange = { includeSymbols = it }, colors = CheckboxDefaults.colors(checkedColor = Color(0xFFFF007F)))
                            Text("SYMBOLS", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = includeNumbers, onCheckedChange = { includeNumbers = it }, colors = CheckboxDefaults.colors(checkedColor = Color(0xFFFF007F)))
                            Text("NUMBERS", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
                            val numbers = "0123456789"
                            val symbols = "!@#$%^&*()_+-=[]{}|;':\",./<>?"
                            var pool = chars
                            if (includeNumbers) pool += numbers
                            if (includeSymbols) pool += symbols

                            var newPass = ""
                            for (i in 0 until genLength.toInt()) {
                                newPass += pool[Random.nextInt(pool.length)]
                            }
                            passInput = newPass
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF007F)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("GENERATE HIGH-ENTROPY PASSWORD", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Add Password credentials Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("REGISTER SECURED ACCOUNT VAULT", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = siteInput,
                        onValueChange = { siteInput = it },
                        label = { Text("Website / Service") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F5FF), unfocusedBorderColor = Color(0xFF1E2235))
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = userInput,
                        onValueChange = { userInput = it },
                        label = { Text("User name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F5FF), unfocusedBorderColor = Color(0xFF1E2235))
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = passInput,
                        onValueChange = { passInput = it },
                        label = { Text("Password Vault") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F5FF), unfocusedBorderColor = Color(0xFF1E2235))
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (siteInput.isNotEmpty() && userInput.isNotEmpty() && passInput.isNotEmpty()) {
                                viewModel.savePassword(siteInput, userInput, passInput)
                                siteInput = ""
                                userInput = ""
                                passInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F5FF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ENCRYPT & PERSIST SECURE CREDENTIALS", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Vault list header
        item {
            Text("AES-256 SECURED VAULT RECORDS (${passwords.size}):", color = Color(0xFF00F5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        items(passwords) { item ->
            var isPassVisible by remember { mutableStateOf(false) }
            val decryptedPassword = remember(item.passwordCipher) {
                try {
                    String(android.util.Base64.decode(item.passwordCipher, android.util.Base64.DEFAULT))
                } catch (e: Exception) {
                    "Decoding failed"
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF00F5FF), modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.site, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("User: ${item.username}", color = Color.Gray, fontSize = 11.sp)
                    Text(
                        text = if (isPassVisible) decryptedPassword else "••••••••••••",
                        color = Color(0xFFFF007F),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row {
                    IconButton(onClick = { isPassVisible = !isPassVisible }) {
                        Icon(
                            imageVector = if (isPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle Pass",
                            tint = Color.Gray
                        )
                    }
                    IconButton(onClick = { viewModel.deletePassword(item) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.8f))
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun AdBlockRulesContent(viewModel: BrowserViewModel) {
    val rules by viewModel.customAdRules.collectAsState()
    var ruleInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Stats Today card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("ADVANCED CONTENT FILTER", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("TOTAL ADS BLOCKED: ${viewModel.blockedCountToday.value}", color = Color(0xFF39FF14), fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Add Rule Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("COMPILE CUSTOM FILTER RULE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Block custom domains, paths or tracking script patterns (e.g. tracking-script.js).", color = Color.Gray, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = ruleInput,
                        onValueChange = { ruleInput = it },
                        label = { Text("Filter rule pattern") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F5FF), unfocusedBorderColor = Color(0xFF1E2235))
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (ruleInput.trim().isNotEmpty()) {
                                viewModel.addAdBlockRule(ruleInput.trim())
                                ruleInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F5FF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ADD RULE", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Rules list Header
        item {
            Text("USER CUSTOM BLOCK RULES (${rules.size}):", color = Color(0xFF00F5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        items(rules) { rule ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F111A), RoundedCornerShape(12.dp))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.FilterAlt, contentDescription = null, tint = Color(0xFFFF007F), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = rule.pattern,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )

                IconButton(onClick = { viewModel.deleteAdBlockRule(rule) }) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun DownloadsContent(viewModel: BrowserViewModel) {
    val downloads by viewModel.downloads.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Downloads Info Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.DownloadForOffline, contentDescription = null, tint = Color(0xFF00F5FF), modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("MULTI-THREAD DOWNLOADS ENGINE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("SESSIONS: ${downloads.size} TOTAL FILES", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Active list header
        item {
            Text("FILE MANAGEMENT DOWNLOAD LOGS:", color = Color(0xFF00F5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        if (downloads.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No file downloads recorded.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }

        items(downloads) { task ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val fileIcon = when {
                            task.fileName.endsWith(".zip") -> Icons.Default.Folder
                            task.fileName.endsWith(".pdf") -> Icons.Default.PictureAsPdf
                            else -> Icons.Default.InsertDriveFile
                        }
                        Icon(imageVector = fileIcon, contentDescription = null, tint = Color(0xFF00F5FF))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(task.fileName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(task.url, color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }

                        // Delete download task icon
                        IconButton(onClick = { viewModel.deleteDownload(task) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (task.status == "COMPLETED") "STATUS: COMPLETED" else "PROGRESS: ${task.progress}%",
                            color = if (task.status == "COMPLETED") Color(0xFF39FF14) else Color(0xFFFFB300),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${task.size / (1024 * 1024)} MB",
                            color = Color.Gray,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { task.progress / 100f },
                        modifier = Modifier.fillMaxWidth().height(4.dp),
                        color = if (task.status == "COMPLETED") Color(0xFF39FF14) else Color(0xFFFFB300),
                        trackColor = Color(0xFF1E2235)
                    )
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
