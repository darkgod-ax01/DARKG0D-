package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "bookmarks")
data class BookmarkItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "passwords")
data class PasswordItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val site: String,
    val username: String,
    val passwordCipher: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val url: String,
    val filePath: String,
    val size: Long,
    val progress: Int,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "tabs")
data class BrowserTab(
    @PrimaryKey val id: String,
    val url: String,
    val title: String,
    val isSelected: Boolean = false,
    val tabGroup: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class SecureNote(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "adblock_rules")
data class AdBlockRule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val pattern: String,
    val isEnabled: Boolean = true,
    val isCustom: Boolean = true
)

@Dao
interface BrowserDao {
    // Bookmarks
    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getBookmarks(): Flow<List<BookmarkItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkItem)

    @Delete
    suspend fun deleteBookmark(bookmark: BookmarkItem)

    // History
    @Query("SELECT * FROM history ORDER BY timestamp DESC")
    fun getHistory(): Flow<List<HistoryItem>>

    @Query("SELECT * FROM history WHERE title LIKE :query OR url LIKE :query ORDER BY timestamp DESC")
    fun searchHistory(query: String): Flow<List<HistoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: HistoryItem)

    @Query("DELETE FROM history")
    suspend fun clearHistory()

    // Passwords
    @Query("SELECT * FROM passwords ORDER BY site ASC")
    fun getPasswords(): Flow<List<PasswordItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPassword(password: PasswordItem)

    @Delete
    suspend fun deletePassword(password: PasswordItem)

    // Downloads
    @Query("SELECT * FROM downloads ORDER BY timestamp DESC")
    fun getDownloads(): Flow<List<DownloadItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadItem): Long

    @Query("UPDATE downloads SET progress = :progress, status = :status WHERE id = :id")
    suspend fun updateDownloadProgress(id: Int, progress: Int, status: String)

    @Delete
    suspend fun deleteDownload(download: DownloadItem)

    // Tabs
    @Query("SELECT * FROM tabs ORDER BY timestamp ASC")
    fun getTabs(): Flow<List<BrowserTab>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTab(tab: BrowserTab)

    @Update
    suspend fun updateTab(tab: BrowserTab)

    @Query("UPDATE tabs SET isSelected = 0")
    suspend fun deselectAllTabs()

    @Query("DELETE FROM tabs WHERE id = :id")
    suspend fun deleteTabById(id: String)

    @Query("DELETE FROM tabs")
    suspend fun clearAllTabs()

    // Notes
    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getNotes(): Flow<List<SecureNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: SecureNote)

    @Delete
    suspend fun deleteNote(note: SecureNote)

    // AdBlock Rules
    @Query("SELECT * FROM adblock_rules")
    fun getAdBlockRules(): Flow<List<AdBlockRule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdBlockRule(rule: AdBlockRule)

    @Delete
    suspend fun deleteAdBlockRule(rule: AdBlockRule)
}

@Database(
    entities = [
        BookmarkItem::class,
        HistoryItem::class,
        PasswordItem::class,
        DownloadItem::class,
        BrowserTab::class,
        SecureNote::class,
        AdBlockRule::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun browserDao(): BrowserDao
}
