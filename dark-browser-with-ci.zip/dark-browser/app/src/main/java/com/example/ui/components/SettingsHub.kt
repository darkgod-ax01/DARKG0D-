package com.example.ui.components

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SecurityManager
import com.example.ui.BrowserViewModel

@Composable
fun SettingsHub(viewModel: BrowserViewModel) {
    val context = LocalContext.current
    val activity = context as? Activity

    val activeTheme by viewModel.themeMode.collectAsState()
    val toolbarPos by viewModel.toolbarPosition.collectAsState()
    val searchEng by viewModel.searchEngine.collectAsState()
    val currentHomepage by viewModel.customHomepage.collectAsState()
    val adBlockEnabled by viewModel.adBlockEnabled.collectAsState()
    val currentWallpaper by viewModel.wallpaperType.collectAsState()

    val isLockEnabled by SecurityManager.isLockEnabled.collectAsState()
    val isSecureModeEnabled by SecurityManager.isSecureModeEnabled.collectAsState()

    var showPinDialog by remember { mutableStateOf(false) }
    var inputPin by remember { mutableStateOf("") }
    var pinMessage by remember { mutableStateOf("Set a 4-digit unlock PIN") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Branding Header Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1E2235), RoundedCornerShape(16.dp))
                    .padding(top = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "DARK BROWSER",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 4.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Privacy • Speed • Freedom",
                        fontSize = 12.sp,
                        color = Color(0xFF00F5FF),
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Developer: Daksh Lambha\nWebsite: dark-chat.mydiscussion.net\nVersion: 1.0.0 Cyber Edition",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Section 1: Browser Engine Setup
        item {
            Text("BROWSER ENGINE PREFERENCES:", color = Color(0xFF00F5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Custom Search engine selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Search Engine Provider", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Resolved search queries query root", color = Color.Gray, fontSize = 11.sp)
                        }
                        var expandedSearch by remember { mutableStateOf(false) }
                        Box {
                            Text(
                                text = searchEng,
                                color = Color(0xFF00F5FF),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { expandedSearch = true }
                                    .background(Color(0xFF1E2235), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                            DropdownMenu(
                                expanded = expandedSearch,
                                onDismissRequest = { expandedSearch = false },
                                modifier = Modifier.background(Color(0xFF0D0E15))
                            ) {
                                listOf("Google", "DuckDuckGo", "Brave", "Bing").forEach { eng ->
                                    DropdownMenuItem(
                                        text = { Text(eng, color = Color.White) },
                                        onClick = {
                                            viewModel.searchEngine.value = eng
                                            expandedSearch = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Custom Homepage url
                    var homepageText by remember { mutableStateOf(currentHomepage) }
                    OutlinedTextField(
                        value = homepageText,
                        onValueChange = {
                            homepageText = it
                            viewModel.customHomepage.value = it
                        },
                        label = { Text("Custom Homepage URL") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00F5FF),
                            unfocusedBorderColor = Color(0xFF1E2235)
                        )
                    )
                }
            }
        }

        // Section 2: Appearance Customization
        item {
            Text("CYBERPUNK VISUAL CUSTOMIZATION:", color = Color(0xFF00F5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Theme selector
                    Text("Select Interface Theme", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val themes = listOf("AMOLED Black", "Cyber Dark", "AMOLED Dark", "Light")
                        themes.forEach { t ->
                            val active = activeTheme == t
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) Color(0xFF1E2235) else Color(0xFF05060A))
                                    .border(1.dp, if (active) Color(0xFF00F5FF) else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.themeMode.value = t }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = t.substringBefore(" "),
                                    color = if (active) Color.White else Color.Gray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Toolbar location
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Navigation Toolbar Position", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Top or Bottom alignment", color = Color.Gray, fontSize = 11.sp)
                        }
                        Row(
                            modifier = Modifier
                                .background(Color(0xFF05060A), RoundedCornerShape(6.dp))
                                .padding(2.dp)
                        ) {
                            listOf("Bottom", "Top").forEach { pos ->
                                val active = toolbarPos == pos
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (active) Color(0xFF1E2235) else Color.Transparent)
                                        .clickable { viewModel.toolbarPosition.value = pos }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(pos, color = if (active) Color(0xFF00F5FF) else Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Home screen wallpaper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Home Wallpaper Pattern", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Dashboard background aesthetic", color = Color.Gray, fontSize = 11.sp)
                        }
                        var expandedWall by remember { mutableStateOf(false) }
                        Box {
                            Text(
                                text = currentWallpaper,
                                color = Color(0xFFFF007F),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { expandedWall = true }
                                    .background(Color(0xFF1E2235), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                            DropdownMenu(
                                expanded = expandedWall,
                                onDismissRequest = { expandedWall = false },
                                modifier = Modifier.background(Color(0xFF0D0E15))
                            ) {
                                listOf("Solid AMOLED", "Cyber Grid", "Neon Radial").forEach { wall ->
                                    DropdownMenuItem(
                                        text = { Text(wall, color = Color.White) },
                                        onClick = {
                                            viewModel.wallpaperType.value = wall
                                            expandedWall = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 3: Privacy & Security center
        item {
            Text("ENTERPRISE PRIVACY & CRYPTO SECURE:", color = Color(0xFF00F5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Adblocker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("AdBlocker Engine (EasyList)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Filter advertisements and popup scripts", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = adBlockEnabled,
                            onCheckedChange = { viewModel.adBlockEnabled.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF39FF14))
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Biometric lock
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Fingerprint, contentDescription = null, tint = Color(0xFF00F5FF), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Secured App Launch Lock", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Require secure PIN upon application opening", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isLockEnabled,
                            onCheckedChange = { active ->
                                if (active) {
                                    showPinDialog = true
                                } else {
                                    SecurityManager.isLockEnabled.value = false
                                    SecurityManager.isAppLocked.value = false
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F5FF))
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Screenshot protection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Screenshot, contentDescription = null, tint = Color(0xFFFF007F), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Screenshot Anti-Leak Protection", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Blocks screenshotting and OS background previews", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isSecureModeEnabled,
                            onCheckedChange = { SecurityManager.toggleSecureMode(activity) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFFF007F))
                        )
                    }
                }
            }
        }

        // Section 4: Privacy Policies
        item {
            Text("LEGAL POLICIES & TERMS OF SERVICE:", color = Color(0xFF00F5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        item {
            var showPolicy by remember { mutableStateOf(false) }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0E15)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showPolicy = !showPolicy }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DARK BROWSER Privacy Policy & Terms", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Icon(
                            imageVector = if (showPolicy) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    }

                    if (showPolicy) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "PRIVACY POLICY:\n" +
                                    "DARK BROWSER operates in compliance with strict sandbox isolation boundaries. " +
                                     "We DO NOT log, track, sell or collect user browser histories, custom adblocker definitions, or credentials stored inside the pass vault. All encryption keys are isolated on-device.\n\n" +
                                    "TERMS OF USE:\n" +
                                    "You are granted complete user freedom to browse, write network scripts, examine elements with desktop DevTools, and communicate with secure AI companions. Misuse of proxies or tunnels for unlawful network interventions is strictly self-governed by the clients.",
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            lineHeight = 16.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(32.dp)) }
    }

    // Set PIN dialog
    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = {
                showPinDialog = false
                SecurityManager.isLockEnabled.value = false
            },
            title = { Text("SETUP ENCRYPTED SECURITY PIN", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace) },
            containerColor = Color(0xFF0D0E15),
            shape = RoundedCornerShape(16.dp),
            text = {
                Column {
                    Text(pinMessage, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
                    OutlinedTextField(
                        value = inputPin,
                        onValueChange = {
                            if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                                inputPin = it
                            }
                        },
                        label = { Text("Enter 4 digits PIN") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F5FF), unfocusedBorderColor = Color(0xFF1E2235))
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputPin.length == 4) {
                            SecurityManager.lockPasscode.value = inputPin
                            SecurityManager.isLockEnabled.value = true
                            SecurityManager.isAppLocked.value = false
                            showPinDialog = false
                            inputPin = ""
                            pinMessage = "Set a 4-digit unlock PIN"
                        } else {
                            pinMessage = "Error: PIN must be exactly 4 numerical digits."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F5FF))
                ) {
                    Text("SET LOCK", color = Color.Black, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showPinDialog = false
                    SecurityManager.isLockEnabled.value = false
                }) {
                    Text("CANCEL", color = Color(0xFFFF007F), fontFamily = FontFamily.Monospace)
                }
            }
        )
    }
}
